# WEEK-05 TASK-02 - Image Resizing With FFmpeg

Vision task title: Detecting Pedestrians and Vehicles in Road Traffic Footage

This task contains the resized dataset images.

Images were scaled with ffmpeg using width 384 and automatic height, preserving aspect ratio:

ffmpeg -i input.jpg -vf scale=384:-1 output.jpg

Because the bounding-box label coordinates are normalized, preserving aspect ratio keeps the label TXT files valid.
