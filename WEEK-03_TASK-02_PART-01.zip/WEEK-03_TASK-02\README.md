# WEEK-03_TASK-02 PART-01

Contains raw video, object detection video, and audio file.
