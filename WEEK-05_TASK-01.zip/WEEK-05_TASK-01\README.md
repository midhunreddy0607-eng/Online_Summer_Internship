# WEEK-05 TASK-01 - Labeling and Dataset Preparation

This task contains the YOLO dataset structure created after labeling.

Includes:

- dataset/data.yaml
- dataset/train.txt
- dataset/val.txt
- dataset/train/images
- dataset/train/labels
- dataset/valid/images
- dataset/valid/labels
- dataset/test/images

Classes:

- 0: person
- 1: car

The label files are in YOLO normalized TXT format.
