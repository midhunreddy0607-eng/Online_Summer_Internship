# WEEK-02 TASK-01

YOLO object detection output.

Contents:

- week-2.jpg: detection result image
- runs/detect_predict: prediction output folder
