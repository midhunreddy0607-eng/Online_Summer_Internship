# WEEK-02 TASK-01

Vehicle detection output.

Contents:

- week-2.jpg: detection result image
- runs/detect_predict: prediction output folder
