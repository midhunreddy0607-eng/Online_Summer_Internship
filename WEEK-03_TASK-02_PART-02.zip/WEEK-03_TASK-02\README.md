# WEEK-03_TASK-02 PART-02

Contains segmentation video and final combined video.
