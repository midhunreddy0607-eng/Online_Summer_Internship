# WEEK-05 TASK-05 - Final Output Video

This task contains the final video made from detected frames.

Includes:

- final_output/detection_output.mp4

The video combines the object-detection output frames into one playable result.
