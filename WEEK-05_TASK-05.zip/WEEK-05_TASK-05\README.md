# WEEK-05 TASK-05 - Final Output Video

Vision task title: Detecting Pedestrians and Vehicles in Road Traffic Footage

This task contains the final video made from detected frames.

Includes:

- final_output/detection_output.mp4

The video combines the detection output frames into one playable result.
