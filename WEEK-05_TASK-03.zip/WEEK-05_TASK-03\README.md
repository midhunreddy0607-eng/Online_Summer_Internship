# WEEK-05 TASK-03 - Model Training

Vision task title: Detecting Pedestrians and Vehicles in Road Traffic Footage

This task contains the object-detection model training output.

Includes:

- training metrics and plots
- confusion matrices
- validation prediction images
- trained weights in training_results/weights

Important weights:

- training_results/weights/best.pt
- training_results/weights/last.pt

Training was run for 50 epochs on the two-class dataset.
