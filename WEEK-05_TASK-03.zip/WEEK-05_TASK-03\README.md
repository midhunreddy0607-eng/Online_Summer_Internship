# WEEK-05 TASK-03 - YOLO Training

This task contains the YOLO training output.

Includes:

- training metrics and plots
- confusion matrices
- validation prediction images
- trained weights in training_results/weights

Important weights:

- training_results/weights/best.pt
- training_results/weights/last.pt

Training was run for 50 epochs using YOLOv8 on the two-class dataset.
