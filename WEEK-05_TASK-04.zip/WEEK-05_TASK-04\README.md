# WEEK-05 TASK-04 - Detection on Test Images

This task contains the model prediction results on the test images.

Includes:

- annotated test images with bounding boxes
- prediction label files in prediction_results/labels

The model used the new Week-05 trained weights to detect the classes person and car.
