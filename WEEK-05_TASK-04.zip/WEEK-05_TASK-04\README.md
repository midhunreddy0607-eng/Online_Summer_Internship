# WEEK-05 TASK-04 - Detection on Test Images

Vision task title: Detecting Pedestrians and Vehicles in Road Traffic Footage

This task contains the model prediction results on the test images.

Includes:

- annotated test images with bounding boxes
- prediction label files in prediction_results/labels

The trained model was used to detect the classes person and car.
